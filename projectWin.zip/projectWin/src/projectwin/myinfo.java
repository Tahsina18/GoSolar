/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;

import javafx.scene.control.CheckBox;

/**
 *
 * @author tahsinasultana
 */
public class myinfo {
//    campusid, streetdb, citydb, statedb, numberdb
    private  String streetdb;
    private  String citydb;
    private  String statedb;
    private  String numberdb;
    
    //constructor 

    public myinfo(String streetdb, String citydb, String statedb, String numberdb) {
        this.streetdb = streetdb;
        this.citydb = citydb;
        this.statedb = statedb;
        this.numberdb = numberdb;
    }

   

    public void setStreetdb(String streetdb) {
        this.streetdb = streetdb;
    }

    public void setCitydb(String citydb) {
        this.citydb = citydb;
    }

    public void setStatedb(String statedb) {
        this.statedb = statedb;
    }

    public void setNumberdb(String numberdb) {
        this.numberdb = numberdb;
    }
    
}
