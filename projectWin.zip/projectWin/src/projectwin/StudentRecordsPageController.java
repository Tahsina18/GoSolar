/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author tahsinasultana
 */
public class StudentRecordsPageController implements Initializable {

    @FXML Button logoutButton; 
    
    @FXML Label test; 
    
    //menu bar buttons 
    @FXML Button homeMenuB; 
    @FXML Button registrationMenuB; 
    @FXML Button studentRecordsMB; 
    @FXML Button studentAccountMB; 
    @FXML Button financialAidMB; 
    @FXML Button personalInfoMB; 
    @FXML Button removeButtonAction; 
    @FXML TextField campus_Id_fordb; 
    
    
    // table setup 
    @FXML TableView <availableClasses> table; 
    // column setup 
    // @FXML private TableColumn < ?, ?> selectCol; 
    @FXML private TableColumn < ?, ?> crnCol; 
    @FXML private TableColumn < ?, ?> subjectCol; 
    @FXML private TableColumn < ?, ?> courseCol; 
    @FXML private TableColumn < ?, ?> creditCol; 
    @FXML private TableColumn < ?, ?> titleCol; 
    @FXML private TableColumn < ?, ?> timeCol; 
    @FXML private TableColumn < ?, ?> instructorCol; 
    @FXML private TableColumn < ?, ?> locationCol; 
    
    
    private IntegerProperty index= new SimpleIntegerProperty();  
    //delete my class 
    @FXML
    private void removeButtonAction (ActionEvent event) throws SQLException{
     availableClasses selrow = table.getSelectionModel().getSelectedItem();
     String deleteThisColumn = selrow.getTitle();
     //System.out.print(deleteThisColumn);
     //String my_campusid=campus_Id_fordb.getText();
     //System.out.print(my_campusid);

//     DELETE FROM Customers
//     WHERE CustomerName='Alfreds Futterkiste';
 try{
    Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "Dalya1234");
    PreparedStatement statement = (PreparedStatement) con.prepareStatement("delete from myclasses where title = ? ");
    statement.setString(1, deleteThisColumn );

    //statement.setString(1, deleteThisColumn );
    statement.executeUpdate(); 
    Deleted();
 }
 catch(SQLException ex){
      System.out.print("failed"); 
      System.err.println("Caught IOException: " + ex.getMessage());
    }
    }
     // go tko MenuRegistration 
    @FXML
    private void registrationMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) registrationMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("MenuRegistration.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void homeMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) homeMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void studentRecordsMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
      stage=(Stage) studentRecordsMB.getScene().getWindow();
      //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentRecordsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
     private void studentAccountMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) studentAccountMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentAccountsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void financialAidMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) financialAidMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("financialAidPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void personalInfoMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) personalInfoMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("personalInfoPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
      
    
    @FXML 
    private void logoutButtonAction (ActionEvent event) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) logoutButton.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        campus_Id_fordb.setPromptText("Enter CampusID");

        loadMyclasses();
            
    }    

    private void loadMyclasses() {
        try {
            //
            //database coonection
            Connection con= DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "admin");
            ObservableList<availableClasses> data= FXCollections.observableArrayList();
           //selectCol.setCellValueFactory(new PropertyValueFactory<>("selectdb"));
            crnCol.setCellValueFactory(new PropertyValueFactory<>("crn"));
            subjectCol.setCellValueFactory(new PropertyValueFactory<>("subject"));
            courseCol.setCellValueFactory(new PropertyValueFactory<>("course"));
            creditCol.setCellValueFactory(new PropertyValueFactory<>("credit"));
            titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
            timeCol.setCellValueFactory(new PropertyValueFactory<>("timedb"));
            instructorCol.setCellValueFactory(new PropertyValueFactory<>("instructor"));
            locationCol.setCellValueFactory(new PropertyValueFactory<>("locationdb"));
            String sql = "select * from myclasses where campusid='dkhatun1'"; 
            PreparedStatement preparedStatement = con.prepareStatement(sql); 
            ResultSet rs = preparedStatement.executeQuery();
            while(rs.next()){
                data.add(new availableClasses(
                rs.getString("crn"),
                rs.getString("subject"),
                rs.getString("course"),
                rs.getString("credit"),
                rs.getString("title"),
                rs.getString("timedb"),
                rs.getString("instructor"),
                rs.getString("locationdb")            
                ));
                table.setItems(data);
                }
                
                preparedStatement.close();
                rs.close();
                

            
        } catch (SQLException ex) {
            System.out.print("failed"); 
            System.err.println("Caught IOException: " + ex.getMessage());
        } 

    }

    private void Deleted() {
 Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Successful");
                    alert.setHeaderText(null);
                    alert.setContentText("Your class is removed!");

                    alert.showAndWait();

    }
    
}
