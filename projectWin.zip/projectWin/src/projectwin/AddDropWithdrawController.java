/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectwin;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author tahsinasultana
 */
public class AddDropWithdrawController implements Initializable {

    @FXML Button logoutButton; 

    //menu bar buttons 
    @FXML Button homeMenuB; 
    @FXML Button registrationMenuB; 
    @FXML Button studentRecordsMB; 
    @FXML Button studentAccountMB; 
    @FXML Button financialAidMB; 
    @FXML Button personalInfoMB; 
    @FXML Button searchClassesButton; 

    @FXML
    private void searchClassesButtonAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) searchClassesButton.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("SearchClasses.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    // go to MenuRegistration 
    @FXML
    private void registrationMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) registrationMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("MenuRegistration.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void homeMenuBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) homeMenuB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("mainPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
    
    @FXML
    private void studentRecordsMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) studentRecordsMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentRecordsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void studentAccountMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) studentAccountMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("studentAccountsPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void financialAidMBAction(ActionEvent e) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) financialAidMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("financialAidPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
     @FXML
    private void personalInfoMBAction(ActionEvent e) throws IOException{
        Stage stage; 
     Parent root;
 

      stage=(Stage) personalInfoMB.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("personalInfoPage.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
    }
      
    
    @FXML 
    private void logoutButtonAction (ActionEvent event) throws IOException{
     Stage stage; 
     Parent root;
 

      stage=(Stage) logoutButton.getScene().getWindow();
        //load up OTHER FXML document
      root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
 
     //create a new scene with root and set the stage
      Scene scene = new Scene(root, stage.getWidth(), stage.getHeight());
      stage.setScene(scene);
      stage.show(); 
        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
